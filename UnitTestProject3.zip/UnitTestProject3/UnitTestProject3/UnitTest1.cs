﻿using System;
using System.Threading;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace UnitTestProject3
{
    [TestClass]
    public class UnitTest1
    {
        IWebDriver driver = new ChromeDriver();
        [TestMethod]
        public void TestMethod1()
        {
            driver.Navigate().GoToUrl("https://www.google.com/");
            Thread.Sleep(1000);
            driver.FindElement(By.Name("q"));
            Assert.AreEqual(driver.Title, "Google");
        }
        [TestMethod]
        public void TestMethod2()
        {
            driver.Navigate().GoToUrl("https://www.google.com/");
            Thread.Sleep(1000);
            driver.FindElement(By.Name("q"));
            Assert.AreEqual(driver.Title, "Google");
        }
        [TestMethod]
        public void TestMethod3()
        {
            driver.Navigate().GoToUrl("https://www.google.com/");
            Thread.Sleep(1000);
            driver.FindElement(By.Name("q"));
            Assert.AreEqual(driver.Title, "Google");
        }
        [TestMethod]
        public void TestMethod4 ()
        {
            driver.Navigate().GoToUrl("https://www.google.com/");
            Thread.Sleep(1000);
            driver.FindElement(By.Name("q"));
            Assert.AreEqual(driver.Title, "Google");
        } 
    }
}
